import pandas as pd
import matplotlib.pyplot as plt

#==============================GENERAL CODE=============================#

#Getting the path to CSV files
st_data_path = "student_records_csv.csv"
tch_data_path = "teacher_records_csv.csv"

#Importing the data of Teachers & Students from CSV
st_df = pd.read_csv(st_data_path)
tch_df = pd.read_csv(tch_data_path)

#=========================== COMMON FUNCTIONS ========================== #

#Used to show full or specific data
def show_data(df):
    clmn = df.columns
    
    print("\n1. See all data\n2. See Specific data")
    choice = input("Select an Option : ")

    # To show full DataFrame
    if choice == "1":
        print(df.to_string())

    # To show specific parts of DataFrame
    elif choice == "2":
        start_adm_no = input(f"\nEnter {clmn[0]} of starting record : ")
        end_adm_no = input(f"Enter {clmn[0]} of ending record : ")
        c_start = input("Enter name of starting column : ")
        c_end = input("Enter name of ending column : ")

        if start_adm_no == '' : r_start_ind = None
        else: r_start_ind = (df[df[clmn[0]] == int(start_adm_no)].index)[0]
        if end_adm_no == '' : r_end_ind = None
        else: r_end_ind = (df[df[clmn[0]] == int(end_adm_no)].index)[0]
        if c_start == '': c_start = None
        if c_end == '': c_end = None
        
        print(df.loc[r_start_ind : r_end_ind, c_start : c_end])
        
    else:
        print("\nInvalid Option Selected")

#Used to add data
def add_data(csv_path, df):
    clmn = list(df.columns) #List of columns in csv
    new_val = [] # Will store the record values of new row

    # To ask the value of all the columns in given CSV from user
    for col_name in clmn:
        val = input(f"Enter {col_name} for new record: ")
        
        if col_name == clmn[0]:
            val = int(val)
        new_val.append(val)

    #Saving the given values in DataFrame and CSV file
    df.loc[len(df.index)] = new_val
    df.sort_values(by=[clmn[0]], inplace=True)
    
    df.to_csv(csv_path, header=True, index=False)

#Used to delete data
def delete_data(csv_path, df):
    clmn = list(df.columns) #List of columns in csv
    record = int(input(f"Enter {clmn[0]} to delete data : "))

    #Getting the positional row index of the desired record to delete
    indx = df[df[clmn[0]] == record].index
    
    df.drop(indx, inplace = True) #Deleting the desired record
    df.to_csv(csv_path, header=True, index=False)   #Saving the changes to CSV
    
# Used to edit data
def edit_data(csv_path, df):
    
    clmn = list(df.columns) #List of columns in csv
    new_val = []
    record = int(input(f"Enter {clmn[0]} of the record to edit : "))

    #Getting the positional row index of the desired record to edit
    indx = df[df[clmn[0]] == record].index

    # To ask the value of all the columns in given CSV from user
    for col_name in clmn:
        val = input(f"Enter new {col_name} for record: ")
        
        if col_name == clmn[0]:
            val = int(val)
        new_val.append(val)

    df.loc[indx] = new_val

    df.to_csv(csv_path, header=True, index=False)

#Used to QUIT/EXIT the program
def quit_program():
    quit()

# ====================================================================== #
#========================== CODE FOR TEACHER DATA ==========================#

#Used to show graphs related to teachers' records
def tch_graphs():
    print("\n", "-"*30, "Select Graph", "-"*30)
    print("=> Line Graph :\n1. Joining Year vs. Number of Teachers joined")
    print("=> Bar Graphs :\n2. Grade vs. Number of Teachers")
    print("=> Histograms :\n3. Salary vs. Number of Teachers\n")

    choice = input("Select a graph : ")
    
    # Graph of Joining Year vs. Number of Teachers
    if choice == '1':
        years = range(2010, 2025)
        teachers = []
        for yr in years :
            tch_join = tch_df[tch_df['Join_Year']==yr].size
            teachers.append(tch_join)
        plt.plot(years, teachers, markersize=4, marker='d', color='r', markeredgecolor='k')
        plt.show()

    # Grade vs. Number of Teachers
    elif choice == '2':
        x_values = ['NTT', 'PRT', 'TGT', 'PGT']
        ntt = tch_df[tch_df['Grade']=='NTT']['Grade'].size
        prt = tch_df[tch_df['Grade']=='PRT']['Grade'].size
        tgt = tch_df[tch_df['Grade']=='TGT']['Grade'].size
        pgt = tch_df[tch_df['Grade']=='PGT']['Grade'].size
        y_values = [ntt, prt, tgt, pgt]
        plt.bar(x_values, y_values)
        plt.xlabel("Grade")
        plt.ylabel("Number of Teachers")
        plt.title("Grade vs. Number of Teachers")
        plt.show()

    # Salary vs. Number of Teachers
    elif choice == '3':
        salary = tch_df['Salary'].values
        plt.hist(salary, bins=5, histtype='step', color='red')
        plt.xlabel("Salary")
        plt.ylabel("Number of Teachers")
        plt.title("Histogram of Salary of Teachers")
        plt.grid()
        plt.show()
    
    else:
        print("Selected option is Invalid")

#Used to show & use operations on teachers' data
def show_teacher_operations():

    #Using loop to run the option selection after every operation is completed
    while True :
        
        #Printing message for USER
        print("\n", "-"*27, "Select an operation to perform on Teachers' data","-"*27,  "\n", end='')
        print("1. Display Data\n2. Add Data\n3. Delete Data\n4. Edit Data\n5. Show Graphs\n6. Back\n7. Exit")

        #Option selection
        selection = input("Select an Option : ")

        #Checking if the selection is valid or not and calling related function if valid
        if selection == "1":
            show_data(tch_df)
            
        elif selection == "2":
            add_data(tch_data_path, tch_df)
            
        elif selection == "3":
            delete_data(tch_data_path, tch_df)
            
        elif selection == "4":
            edit_data(tch_data_path, tch_df)
            
        elif selection == "5":
            tch_graphs()
        
        elif selection == "6":
            menu()
            
        elif selection == "7":
            quit_program()
            
        else:
            print("\nThis Selection is Invalid")
            continue

        input("\nType anything to continue")

# ===================================================================== #
#========================== CODE FOR STUDENT DATA =========================#

#Used to show graphs of student data
def st_graphs():
    print("\n", "-"*30, "Select Graph", "-"*30)
    print("1. Class vs Number of students\n2. Gender vs. Number of students\n3. House vs. Number of students\n4. Travel Mode vs. Number of students")

    choice = input("Select a graph : ")

    # Graph of Class vs Number of Students
    if choice == '1':
        x_values = ["Nursery", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]
        nursery = st_df[st_df['Class']=='Nursery']['Class'].size
        first = st_df[st_df['Class']=='1']['Class'].size
        second = st_df[st_df['Class']=='2']['Class'].size
        third = st_df[st_df['Class']=='3']['Class'].size
        fourth = st_df[st_df['Class']=='4']['Class'].size
        fifth = st_df[st_df['Class']=='5']['Class'].size
        sixth = st_df[st_df['Class']=='6']['Class'].size
        seventh = st_df[st_df['Class']=='7']['Class'].size
        eight = st_df[st_df['Class']=='8']['Class'].size
        nine = st_df[st_df['Class']=='9']['Class'].size
        ten = st_df[st_df['Class']=='10']['Class'].size
        eleven = st_df[st_df['Class']=='11']['Class'].size
        twelve = st_df[st_df['Class']=='12']['Class'].size
        y_values = [nursery, first, second, third, fourth, fifth, sixth, seventh, eight, nine, ten, eleven, twelve]
        plt.bar(x_values, y_values)
        plt.xlabel("Class")
        plt.ylabel("Number of students")
        plt.title("Number of Students in Each Class")
        plt.show()

   # Graph of Gender vs Number of Students
    elif choice == '2':
        x_values = ["Male", "Female"]
        n_male = st_df[st_df['Gender']=='Male']['Gender'].size
        n_female = st_df[st_df['Gender']=='Female']['Gender'].size
        y_values = [n_male, n_female]
        plt.bar(x_values, y_values, width=0.3, color=['dodgerblue', 'magenta'])
        plt.xlabel("Gender")
        plt.ylabel("Number of Students")
        plt.title("Number of Students of Each Gender")
        plt.show()

    # Graph of House vs Number of Students
    elif choice == '3':
        x_values = ["Red", "Yellow", "Green", "Blue"]
        red = st_df[st_df['House']=='Red']['House'].size
        yellow = st_df[st_df['House']=='Yellow']['House'].size
        green = st_df[st_df['House']=='Green']['House'].size
        blue = st_df[st_df['House']=='Blue']['House'].size
        y_values = [red, yellow, green, blue]
        plt.bar(x_values, y_values, color=['red', 'gold', 'lime', 'dodgerblue'])
        plt.xlabel("House")
        plt.ylabel("Number of Students")
        plt.title("Number of Students in Each House")
        plt.show()

    # Graph of Mode of Transportation vs Number of Students
    elif choice == '4':
        x_values = ["Bus", "Van", "Self"]
        bus = st_df[st_df['Tra_Mode']=='Bus']['Tra_Mode'].size
        van = st_df[st_df['Tra_Mode']=='Van']['Tra_Mode'].size
        self = st_df[st_df['Tra_Mode']=='Self']['Tra_Mode'].size
        y_values = [bus, van, self]
        plt.bar(x_values, y_values, color=['orange', 'lime', 'blue'])
        plt.xlabel("Mode of Transportation")
        plt.ylabel("Number of Students")
        plt.title("Number of Students in Each Mode of Transport")
        plt.show()
    
    else:
        print("Selected option is Invalid")

def show_student_operations():
    #Using loop to run the option selection after every operation is completed
    while True :
        
        #Printing message for USER
        print("\n", "-"*27, "Select an operation to perform on Students' data","-"*27,  "\n", end='')
        print("1. Display Data\n2. Add Data\n3. Delete Data\n4. Edit Data\n5. Show Graphs\n6. Back\n7. Exit")

        #Option selection
        selection = input("Select an Option : ")

        #Checking if the selection is valid or not and calling related function if valid
        if selection == "1":
            show_data(st_df)
            
        elif selection == "2":
            add_data(st_data_path, st_df)
            
        elif selection == "3":
            delete_data(st_data_path, st_df)
            
        elif selection == "4":
            edit_data(st_data_path, st_df)
            
        elif selection == "5":
            st_graphs()
        
        elif selection == "6":
            menu()
            
        elif selection == "7":
            quit_program()
            
        else:
            print("\nThis Selection is Invalid")
            continue

        input("\nType anything to continue")

# ====================================================================== #

#Main Menu
def menu():

    #Using loop to run the option selection untill a valid option is not selected
    while True :
        
        #Printing message for USER
        print("\n", "====X====Welcome To The School Management System====X====", "\n")
        print("Select Data To Operate Upon :-")
        print("1. Teacher Data\n2. Student Data\n3. EXIT")

        #Option selection
        selection = input("Select an Option : ")

        #Checking if the selection is valid or not and calling related function if valid
        if selection == "1":
            show_teacher_operations()
            break
        
        elif selection == "2":
            show_student_operations()
            break
        
        elif selection == "3":
            quit_program()
            break
        
        else:
            print("\nThis Selection is Invalid")

#Initializing the program with menu function
menu()
